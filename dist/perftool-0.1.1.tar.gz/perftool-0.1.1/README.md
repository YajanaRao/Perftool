#Perftool
The Performance Tool

Features
Measure the time taken for the execution of system commands and record the performance while executing
