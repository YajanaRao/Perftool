from setuptools import setup

setup(name='perftool',
      version='0.1',
      description='The Performance Tool',
      url='https://github.com/Yajan/Perftool.git',
      author='Yajana',
      author_email='yajananrao@gmail.com',
      license='Apache License',
      packages=['perftool'],
      zip_safe=False)